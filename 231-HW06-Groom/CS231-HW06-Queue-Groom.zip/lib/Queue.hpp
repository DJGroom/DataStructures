
/*
================================================================================#=
CLASS:   Queue
Version: Circular/Floating Array
FILE:    lib/Queue.hpp

ACKNOWLEDGEMENTS:
The original version of this code is found in:
    C++ Plus Data Structures, Sixth Edition (Dale et al., 2018)
    Jones & Bartlett Learning, LLC
    Chapter 5
    Available for download here:
        https://www.jblearning.com/catalog/productdetails/9781284089189#productInfo
================================================================================#=
*/

#pragma once
#include "ItemType.hpp"
#include <string>

// -----------------------------------------------------------------------------+-
// In this class, we assume that ItemType.h provides:
//   ItemType:      the data type of the object elements stored in the list
//
//   RelationType:  {LESS, GREATER, EQUAL}
//   Member function ComparedTo(ItemType item) which returns 
//       LESS, if self "comes before" item
//       GREATER, if self "comes after" item
//       EQUAL, if self and item are the same
// -----------------------------------------------------------------------------+-


class Queue
{
private:
    ItemType*  queueItems;
    int        queueSize;

    int        frontIdx;
    int        rearIdx;
    int        queueDepth;

public:
    // -----------------------------------------------------+-
    // Constructor Destructor
    // -----------------------------------------------------+-
    Queue(int given_max_depth);
    Queue() : Queue(240){};
    ~Queue();

    // -----------------------------------------------------+-
    // Observers
    // -----------------------------------------------------+-
    bool     IsFull()   const;
    bool     IsEmpty()  const;
    int      GetDepth() const;

    std::string &ToString(std::string &s) const;

    // -----------------------------------------------------+-
    // Transformers
    // -----------------------------------------------------+-
    void      Enqueue(ItemType given_item);
    ItemType  Dequeue();
    void      MakeEmpty();
};



