
Class Matrix {

char matrix[10][10];
int row, column;
MakeEmpty();
StoreValue();
Add();
Subtract();
Copy();  

}
