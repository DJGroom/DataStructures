
/*
================================================================================#=
Fraction Type Unit Test Driver

FILE: fraction_type.cpp
Implementation file for the FractionType class.

ACKNOWLEDGEMENTS:
This code is substantially based on:
    Fraction Class Case Study
    C++ Plus Data Structures
    Nell Dale, University of Texas, Austin
    Chip Weems, University of Massachusetts, Amherst
    Tim Richards, University of Massachusetts, Amherst
    Jones & Bartlett Learning, LLC
================================================================================#=
*/
#include "fraction_type.hpp"

// -----------------------------------------------------------------------------+-
// Constructors
// -----------------------------------------------------------------------------+-
FractionType::FractionType(int given_numerator, int given_denominator)
{
    initialize(given_numerator, given_denominator);
}
FractionType::FractionType()
{
    initialize(1, 1);
}
void FractionType::initialize(int given_numerator, int given_denominator)
{
    numerator   = given_numerator;
    denominator = given_denominator;
};

// -----------------------------------------------------------------------------+-
// Simple Getters
// -----------------------------------------------------------------------------+-
int FractionType::NumeratorIs()
{
    return numerator;
}


    //
    // TODO: Add the implementations for:
    // DenominatorIs, IsZero, IsNotProper, and ConvertToProper
    //
int FractionType::DenominatorIs()
{
    return denominator;
}
bool FractionType::IsZero()
{
    return(numerator == 0);
}
bool FractionType::IsNotProper(){
    return(numerator >= denominator);
}
double FractionType::ConvertToProper(){
double decimal;
numerator = numerator % denominator;
decimal = numerator / denominator;
return decimal;
}

