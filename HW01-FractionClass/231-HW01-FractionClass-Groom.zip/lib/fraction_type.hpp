
/*
================================================================================================#=
Fraction Type Unit Test Driver

FILE: fraction_type.hpp
Specification file for the FractionType class.

ACKNOWLEDGEMENTS:
This code is substantially based on:
    Fraction Class Case Study
    C++ Plus Data Structures
    Nell Dale, University of Texas, Austin
    Chip Weems, University of Massachusetts, Amherst
    Tim Richards, University of Massachusetts, Amherst
    Jones & Bartlett Learning, LLC
================================================================================================#=
*/

class FractionType
{
public:
    // Constructors
    // Pre:  None
    // Post: Fraction is initialized to give or default values.
    FractionType();
    FractionType(int numerator, int denominator);

    int NumeratorIs();
    // Pre:  Fraction has been initialized.
    // Post: Numerator is returned.

    //
    // TODO: Add the declarations for:
    // DenominatorIs, IsZero, IsNotProper, and ConvertToProper
    //
    int DenominatorIs();
    //Pre: denominator has been initialized. 
    //Post: denominator returned
    bool IsZero();
    //Pre: Fraction has been intialized.
    //Post: True if numerator is zero.
    bool IsNotProper();
    //Pre: Numerator and denominator has been initialized
    //Post: Fraction is identified as proper or not proper
    double ConvertToProper();
    //Pre: Numerator and denominator has been initialized
    //Post: Fraction is now proper decimal
private:
    int numerator;
    int denominator;
    void initialize(int given_numerator, int given_denominator);
};

