class Fibo
{
    private:
        int odd_fibnum;
        int even_fibnum;
        int itervation_value;
        int result;
    public:
        Fibo();
        void fibiFunction(int fibinacci_num);
        int GetResult();
};